## A Quarto Manuscript Template

- [github published link](https://nils-holmberg.github.io/manuscript-template-jupyter/)

This is a template repo for generating a manuscript from Quarto that accompanies the tutorial at: [Quarto Manuscripts: Jupyter Lab](https://quarto.org/docs/manuscripts/authoring/jupyterlab.html)


